
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.2'
version = '1.16.2'
full_version = '1.16.2'
git_revision = '0eeb158ead494e130a25239ac8473a06451b1072'
release = True

if not release:
    version = full_version
